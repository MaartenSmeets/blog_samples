# print version
# print sys.platform
print "-----------------------------"
y = "Yes"
Y = y
n = "No"
N = n
from oracle.ateam import MDSUtils
mdsUtils = MDSUtils()
# setup Connection parameters
# The first call (createFolder, deleteFolder) will create the MDSInstance with those parameters.
mdsUtils.setUserName("TEST_MDS")
mdsUtils.setPassword("welcome1")
mdsUtils.setPartition("soa-infra")
mdsUtils.setDbUrl("jdbc:oracle:thin:@ateam-hq53.us.oracle.com:1521:XE")
#
response = input("Do we create the \"oliv\" directory ? [y|n] > ")
if response == y:
  print "Creating directory"
  mdsUtils.createFolder("/oliv")
response = input("Do we delete the \"oliv\" directory ? [y|n] > ")
if response == y:
  print "Deleting directory"
  mdsUtils.deleteFolder("/oliv")
print "Done."  
print "Bye now"
