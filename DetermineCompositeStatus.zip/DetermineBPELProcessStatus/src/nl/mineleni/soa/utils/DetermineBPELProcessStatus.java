package nl.mineleni.soa.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import java.net.MalformedURLException;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;

import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import weblogic.management.MBeanHome;
import weblogic.management.mbeanservers.compatibility.internal.MBeanHomeImpl;

public class DetermineBPELProcessStatus extends HttpServlet {
  public DetermineBPELProcessStatus() {
    super();
  }

  private static MBeanServerConnection getRemoteConnection(String hostname,
                                                           String portString,
                                                           String username,
                                                           String password) throws IOException,
                                                                                   MalformedURLException {
    JMXConnector connector = null;
    MBeanServerConnection connection = null;
    //System.out.println("ServerDetails---Started in initConnection");
    String protocol = "t3";
    Integer portInteger = Integer.valueOf(portString);
    int port = portInteger.intValue();
    String jndiroot = "/jndi/";

    String mserver = "weblogic.management.mbeanservers.domainruntime";
    //String mserver = "weblogic.management.mbeanservers.domainruntime";
    JMXServiceURL serviceURL =
      new JMXServiceURL(protocol, hostname, port, jndiroot + mserver);
    Hashtable h = new Hashtable();
    h.put(Context.SECURITY_PRINCIPAL, username);
    h.put(Context.SECURITY_CREDENTIALS, password);
    h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES,
          "weblogic.management.remote");
    connector = JMXConnectorFactory.connect(serviceURL, h);
    connection = connector.getMBeanServerConnection();
    return connection;
  }

  private static MBeanServerConnection getLocalConnection() throws NamingException {
    InitialContext ctx = new InitialContext();
    MBeanServer server = (MBeanServer)ctx.lookup("java:comp/env/jmx/runtime");
    return server;
  }

  private static String stackTraceToString(Throwable e) {
    String retValue = null;
    StringWriter sw = null;
    PrintWriter pw = null;
    try {
      sw = new StringWriter();
      pw = new PrintWriter(sw);
      e.printStackTrace(pw);
      retValue = sw.toString();
    } finally {
      try {
        if (pw != null)
          pw.close();
        if (sw != null)
          sw.close();
      } catch (IOException ignore) {
        //System.out.println(stackTraceToString(e));
      }
    }
    return retValue;
  }

  public void doPost(HttpServletRequest request,
                     HttpServletResponse response) throws ServletException,
                                                          IOException {
    doGet(request, response);
  }

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response) throws ServletException,
                                                         IOException {
    PrintWriter out = response.getWriter();
    String name = request.getParameter("name");
    String partition = request.getParameter("partition");
    String revision = request.getParameter("revision");
    Date myDate = new Date();

    System.out.println(myDate.toString() +
                       " DetermineBPELProcessStatus: Request received; name=" +
                       name + " partition=" + partition + " revision=" +
                       revision);
    try {
      MBeanServerConnection myCon = getLocalConnection();
      ObjectName myObj;
      myObj = getComposite(getLocalConnection(), name, revision, partition);
      out.println(displayCompositeStateMode(myCon, myObj));
    } catch (Exception e) {
      out.println(stackTraceToString(e));
    }
  }

  private static Set<ObjectName> getComposites(MBeanServerConnection myCon) throws IOException,
                                                                                   MalformedObjectNameException {
    return myCon.queryNames(new ObjectName("oracle.soa.config:Application=soa-infra,j2eeType=SCAComposite,wsconfigtype=WebServicesConfig,*"),
                            null);
  }

  private static ObjectName getComposite(MBeanServerConnection myCon,
                                         String compositename,
                                         String compositerevision,
                                         String compositepartition) throws IOException,
                                                                           MalformedObjectNameException {


    Set<ObjectName> myResult =
      myCon.queryNames(new ObjectName("oracle.soa.config:Application=soa-infra,j2eeType=SCAComposite,*,wsconfigtype=WebServicesConfig"),
                       null);

    ObjectName[] myArr = myResult.toArray(new ObjectName[myResult.size()]);
    //System.out.println("Composites found: "+myArr.length);
    for (ObjectName myName : myArr) {
      if (getCompositeName(myName).equals(compositename) &&
          getCompositePartition(myName).equals(compositepartition) &&
          getCompositeRevision(myName).equals(compositerevision)) {
        return myName;
      }
    }
    return null;
  }

  private static String getCompositeState(MBeanServerConnection myCon,
                                          ObjectName composite) throws MBeanException,
                                                                       AttributeNotFoundException,
                                                                       InstanceNotFoundException,
                                                                       ReflectionException,
                                                                       IOException {
    String retVal = "";
    try {
      retVal = (String)myCon.getAttribute(composite, "State");
    } catch (Exception e) {
      return "";
    }
    return retVal;
  }

  private static String getCompositePartition(ObjectName composite) {
    String retVal = "";
    try {
      retVal = composite.getKeyProperty("partition");
    } catch (Exception e) {
      return "";
    }
    return retVal;
  }

  private static String getCompositeMode(MBeanServerConnection myCon,
                                         ObjectName composite) throws MBeanException,
                                                                      AttributeNotFoundException,
                                                                      InstanceNotFoundException,
                                                                      ReflectionException,
                                                                      IOException {
    String retVal = "";
    try {
      retVal = (String)myCon.getAttribute(composite, "Mode");
    } catch (Exception e) {
      return "";
    }
    return retVal;
  }

  private static String getCompositeName(ObjectName composite) {
    String retVal = "";
    try {
      retVal = composite.getKeyProperty("name").replace("\"", "");
    } catch (Exception e) {
      return "";
    }
    return retVal;
  }

  private static String getCompositeRevision(ObjectName composite) {
    String retVal = "";
    try {
      retVal = composite.getKeyProperty("revision");
    } catch (Exception e) {
      return "";
    }
    return retVal;
  }

  private static String displayComposite(MBeanServerConnection myCon,
                                         ObjectName composite) throws MBeanException,
                                                                      AttributeNotFoundException,
                                                                      InstanceNotFoundException,
                                                                      ReflectionException,
                                                                      IOException {
    return ("Name: " + getCompositeName(composite) + " Revision: " +
            getCompositeRevision(composite) + " Partition: " +
            getCompositePartition(composite) + " " +
            displayCompositeStateMode(myCon, composite));
  }

  private static String displayCompositeStateMode(MBeanServerConnection myCon,
                                                  ObjectName composite) throws MBeanException,
                                                                               AttributeNotFoundException,
                                                                               InstanceNotFoundException,
                                                                               ReflectionException,
                                                                               IOException {
    return ("State: " + getCompositeState(myCon, composite) + " Mode: " +
            getCompositeMode(myCon, composite));
  }
/*
  public static void main(String[] args) {
    String host = "xxx";
    String port = "xxx";
    String user = "xxx";
    String password = "xxx";

    MBeanServerConnection myCon;
    try {
      myCon = getRemoteConnection(host, port, user, password);
      ObjectName myObj = getComposite(myCon, "name", "revision", "partition");
      System.out.println(displayComposite(myCon, myObj));


      Set<ObjectName> myObjNs = getComposites(myCon);
      /*
      for (ObjectName myObjN : myObjNs) {

        System.out.println("Name: " + myObjN.getKeyProperty("name") +
                           " State: " + myCon.getAttribute(myObjN, "State") +
                           " Mode: " + myCon.getAttribute(myObjN, "Mode"));

      }

    } catch (Exception e) {
      System.out.println(stackTraceToString(e));
    }
  }
*/
}
