package valves;
 
import java.io.*;
import javax.crypto.*;
import javax.crypto.spec.*;
 
import oracle.tip.pc.services.pipeline.AbstractStagedValve;
import oracle.tip.pc.services.pipeline.InputStreamContext;
import oracle.tip.pc.services.pipeline.PipelineException;
import oracle.tip.pc.services.pipeline.PipelineUtils;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
 
/**
 * Simple Decryption valve that uses DES algorightm
 * 
 * You must note that this class uses AbstractStagedValve. By using the
 * AbstractStagedValve, the valve notifies the pipeline that the valve will take
 * care of its own staging and cleanup
 * 
 */
public class SimpleDecryptValve extends AbstractStagedValve {
 
      // Staging file where the intermediate decrypted content is kept
      private File stagingFile = null;
 
      /**
       * Called by the adapter. All the binding/reference properties in the
       * composite are available to the pipeline via the pipeline context For
       * example <service name="FlatStructureIn"> <interface.wsdl
       * interface="http://xmlns.oracle.com/pcbpel/adapter/file/FlatStructureIn/#wsdl.interface(Read_ptt)"/>
       * <binding.jca config="FlatStructureIn_file.jca"> <property
       * name="myCipherKey" source="" type="xs:string" many="false"
       * override="may">somekey</property> </binding.jca> </service>
       * 
       */
      public InputStreamContext execute(InputStreamContext inputStreamContext)
                  throws IOException, PipelineException {
 
            // Read the cipher key from the adapter binding property 'myCipherKey'
            String cipherKey = (String) getPipeline().getPipelineContext()
                        .getProperty("myCipherKey");
 
            // If key is blank, default to some hard-coded value
            if (PipelineUtils.isBlank(cipherKey)) {
                  System.out.println("using default ciper key");
                  cipherKey = "desvalve";
            }
            // Create an instance of the Cipher
            byte key[] = cipherKey.getBytes();
            SecretKeySpec secretKey = new SecretKeySpec(key, "DES");
            Cipher decrypt = null;
            try {
                  decrypt = Cipher.getInstance("DES/ECB/PKCS5Padding");
            } catch (NoSuchPaddingException nspe) {
                  throw new PipelineException("Unable to get cipher instance", nspe);
            } catch (NoSuchAlgorithmException nsae) {
                  throw new PipelineException("Invalid cipher algorithm", nsae);
            }
            try {
                  decrypt.init(Cipher.DECRYPT_MODE, secretKey);
            } catch (InvalidKeyException ike) {
                  throw new PipelineException("Invalid secret key", ike);
            }
            // original input stream from caller. For example, adapter
            InputStream originalInputStream = null;
            CipherInputStream cis = null;
            try {
                  originalInputStream = inputStreamContext.getInputStream();
                  cis = new CipherInputStream(originalInputStream, decrypt);
            } catch (Exception e) {
                  throw new PipelineException("Unable to create cipher stream", e);
            }
            // Since we're using a staged valve, we will store the decrypted content
            // in a staging file
            // In this case, we're leveraging the File/Ftp Adapter control directory
            // to store the content, but, the staging file can be placed anywhere
            this.stagingFile = PipelineUtils.getUniqueStagingFile(getPipeline()
                        .getPipelineContext().getStagingDirectory());
 
            // Write the decrypted content to the staging file
            OutputStream os = new FileOutputStream(this.stagingFile);
            byte[] b = new byte[8];
            int i = cis.read(b);
            while (i != -1) {
                  os.write(b, 0, i);
                  i = cis.read(b);
            }
            os.flush();
            os.close();
            cis.close();
 
            // Open a stream to the staging file and return it back to the caller
            InputStream in = new FileInputStream(this.stagingFile);
            // close the input stream passed in this invocation
            inputStreamContext.closeStream();
            // set the input stream to staging file and return
            inputStreamContext.setInputStream(in);
            return inputStreamContext;
 
      }
 
      /*
       * (non-Javadoc)
       * 
       * @see oracle.tip.pc.services.pipeline.AbstractStagedValve#getStagingFile()
       */
      public File getStagingFile() {
            return stagingFile;
      }
 
      /*
       * Delete the staging file if there is one (non-Javadoc)
       * 
       * @see oracle.tip.pc.services.pipeline.AbstractValve#finalize(oracle.tip.pc.services.pipeline.InputStreamContext)
       */
      public void finalize(InputStreamContext ctx) {
            try {
                  cleanup();
            } catch (Exception e) {
            }
      }
 
      /*
       * Use this method to delete the staging file (non-Javadoc)
       * 
       * @see oracle.tip.pc.services.pipeline.AbstractStagedValve#cleanup()
       */
      public void cleanup() throws PipelineException, IOException {
 
            if (stagingFile != null && this.stagingFile.exists()) {
                  this.stagingFile.delete();
            }
            this.stagingFile = null;
      }
 
}