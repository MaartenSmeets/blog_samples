package valves;
 
import java.io.*;
import java.util.zip.*;
 
import oracle.tip.pc.services.pipeline.AbstractValve;
import oracle.tip.pc.services.pipeline.InputStreamContext;
import oracle.tip.pc.services.pipeline.PipelineException;
 
/**
 * A simple valve to process zip files.
 * The valve processes the first entry from the zip file. 
 * If you need to process multiple files, you will need
 * a re-entrant valve
 **/
public class SimpleUnzipValve extends AbstractValve {
 
      public InputStreamContext execute(InputStreamContext inputStreamContext)
                  throws IOException, PipelineException {
            // Get the input stream that is passed to the Valve
            InputStream originalInputStream = inputStreamContext.getInputStream();
 
            // Create a new ZIP input stream
            ZipInputStream zipStream = null;
            try {
                  zipStream = new ZipInputStream(originalInputStream);
                  ZipEntry entry = null;
                  // In this sample valve, lets pick up the first entry
                  if ((entry = zipStream.getNextEntry()) != null) {
                        System.out.println("Unzipping " + entry.getName());
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[4096];
                        int len = 0;
                        while ((len = zipStream.read(buf)) > 0) {
                              bos.write(buf, 0, len);
                        }
                        bos.close(); // no-op but still ...
                        ByteArrayInputStream bin = new ByteArrayInputStream(bos
                                    .toByteArray());
                        // This is where the Valve returns the inputstream to the caller
                        // Example, Adapter
                        // return the newly created inputstream as a part of the context
                        inputStreamContext.setInputStream(bin);
 
                        return inputStreamContext;
                  }
            } finally {
                  if (zipStream != null) {
                        zipStream.close();
                  }
            }
            // return null if no data
            return null;
 
      }
 
      @Override
      // Not required for this simple valve
      public void finalize(InputStreamContext in) {
 
      }
 
      @Override
      // Not required for this simple valve
      public void cleanup() throws PipelineException, IOException {
 
      }
      
 
}