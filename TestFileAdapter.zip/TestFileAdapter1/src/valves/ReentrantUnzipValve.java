package valves;
 
import java.io.*;
import java.util.zip.*;
import java.util.*;
 
import oracle.tip.pc.services.pipeline.AbstractStagedValve;
import oracle.tip.pc.services.pipeline.InputStreamContext;
import oracle.tip.pc.services.pipeline.PipelineException;
import oracle.tip.pc.services.pipeline.PipelineUtils;
 
/**
 * A re-entrant valve is one that can be invoked multiple times
 * and on each invocation it must return a new stream.
 * This concept is used here in this sample to process
 * a zipped file containing multiple entries.
 * 
 * If a valve is marked as re-entrant, then the caller (adapter), 
 * calls hasNext() on the valve to check if there are more 
 * streams available
 */
public class ReentrantUnzipValve extends AbstractStagedValve {
 
      //member variables
      private boolean initialized = false;
 
      private List<String> files = null;
 
      private File currentFile = null;
 
      private File unzipFolder = null;
 
      /**
       * On the first invocation, this valve unzips the zip file into
       * a staging area and returns a stream the first unzipped file
       * On subsequent iterations, the valve returns streams to 
       * subsequent files.
       */
      public InputStreamContext execute(InputStreamContext inputStreamContext)
                  throws IOException, PipelineException {
            String fileName = "";
            //the first time that the valve is invoked, unzip the file into
            //the staging area
            if (!initialized) {
                  files = new ArrayList<String>();
                  //Get hold of the File/Ftp adapter control directory 
                  File controlDirectory = getPipeline().getPipelineContext()
                              .getStagingDirectory();
                  //Create if required
                  if (!controlDirectory.exists()) {
                        controlDirectory.mkdirs();
                  }
                  //Generate a unique folder to store the staging files 
                  String digestPath = "";
                  try {
                        digestPath = PipelineUtils.genDigest(inputStreamContext
                                    .getMessageOriginReference());
                  } catch (Exception e) {
                        digestPath = String.valueOf(inputStreamContext
                                    .getMessageOriginReference().hashCode());
                  }
                  unzipFolder = new File(controlDirectory, digestPath);
                  if (!unzipFolder.exists())
                        unzipFolder.mkdirs();
                  //unzip the files into the staging folder
                  unzipToDirectory(inputStreamContext.getInputStream(), unzipFolder);
                  //store the file names into the list
                  PipelineUtils.listFiles(unzipFolder, files);
                  //close the input stream
                  inputStreamContext.closeStream();
            }
            initialized = true;
            //return the next one in the list
            if (files != null && files.size() > 0) {
                  fileName = files.remove(0);
                  currentFile = new File(fileName);
                  System.out.println("Returning file[" + fileName + "]");
                  //Open a stream to the file and return to caller. For example,  adapter
                  FileInputStream fis = new FileInputStream(currentFile);
                  inputStreamContext.setInputStream(fis);
                  /*For re-entrant valves, setting the message key is
                   important since this allows the caller to distinguish
                   between parts for the same message. for example, in the 
                   case of zip file in this example, the
                   messageOriginReference will be same, but, the individual
                   message keys will vary. For example, the messageOriginReference
                   will be "/input/in.zip", whereas message key might be something
                   like "dir1/address-csv1.txt", "dir1/address-csv2.txt" and so on
                   */
                  inputStreamContext.setMessageKey(fileName);
                  return inputStreamContext;
            } else {
                  //return null if no more files
                  return null;
            }
      }
 
      /*
       * Adapter calls this to check if there are more files
       * @see oracle.tip.pc.services.pipeline.AbstractValve#hasNext()
       */
      public boolean hasNext() {
            return (files != null && files.size() > 0);
      }
 
      /*
       * Returns the current file being processed
       * @see oracle.tip.pc.services.pipeline.AbstractStagedValve#getStagingFile()
       */
      public File getStagingFile() {
            return currentFile;
      }
 
      /*
       * delete the current file once the entry has been published to binding component
       * @see oracle.tip.pc.services.pipeline.AbstractValve#finalize(oracle.tip.pc.services.pipeline.InputStreamContext)
       */
      public void finalize(InputStreamContext ctx) {
 
            if (currentFile != null && currentFile.exists()) {
                  currentFile.delete();
            }
      }
 
      /* 
       * Cleanup intermediate files
       * @see oracle.tip.pc.services.pipeline.AbstractStagedValve#cleanup()
       */
      public void cleanup() throws PipelineException, IOException {
            PipelineUtils.deleteDirectory(unzipFolder);
            initialized = false;
            if (currentFile != null && currentFile.exists()) {
                  currentFile.delete();
            }
            files = null;
      }
 
      /*
       * Unzip to the directory
       */
      private void unzipToDirectory(InputStream in, File directory)
                  throws IOException {
            ZipInputStream zin = new ZipInputStream(in);
            ZipEntry entry = null;
            if ((entry = zin.getNextEntry()) != null) {
                  do {
                        String entryName = entry.getName();
                        if (!entry.isDirectory()) {
                              File file = new File(directory, entryName);
                              unzipFile(zin, file);
                        }
                  } while ((entry = zin.getNextEntry()) != null);
            }
            zin.close();
      }
 
      private void unzipFile(InputStream in, File file) throws IOException {
            if (!file.getParentFile().exists()) {
                  file.getParentFile().mkdirs();
            }
            OutputStream os = new FileOutputStream(file);
            byte[] buf = new byte[4096];
            int len = 0;
            while ((len = in.read(buf)) > 0) {
                  os.write(buf, 0, len);
            }
            os.close();
      }
 
}