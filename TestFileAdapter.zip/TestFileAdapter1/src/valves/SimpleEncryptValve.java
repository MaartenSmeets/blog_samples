package valves;
 
import java.io.*;
import javax.crypto.*;
import javax.crypto.spec.*;
 
import oracle.tip.pc.services.pipeline.AbstractValve;
import oracle.tip.pc.services.pipeline.InputStreamContext;
import oracle.tip.pc.services.pipeline.PipelineException;
import oracle.tip.pc.services.pipeline.PipelineUtils;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
 
/**
 * Simple Encryption valve that uses DES algorightm
 * 
 */
public class SimpleEncryptValve extends AbstractValve {
 
           
/**
      * Called by the adapter. All the binding/reference properties
      * in the composite are available to the pipeline via 
      * the pipeline context
      * For example
      * <service name="FlatStructureOut">
      *     <interface.wsdl interface="http://xmlns.oracle.com/pcbpel/adapter/file/FlatStructureOut/#wsdl.interface(Write_ptt)"/>
      *     <binding.jca config="FlatStructureOut_file.jca">
      *         <property name="myCipherKey" source="" type="xs:string" many="false" override="may">somekey</property>
      *   </binding.jca>
      * </service>   
      * 
      */
     public InputStreamContext execute(InputStreamContext inputStreamContext)
               throws IOException, PipelineException {
 
          //Read the cipher key from the adapter binding property 'myCipherKey'
          String cipherKey = (String) getPipeline().getPipelineContext()
                    .getProperty("myCipherKey");
 
          //If key is blank, default to some hard-coded value
          if (PipelineUtils.isBlank(cipherKey)) {
               System.out.println("using default ciper key");
               cipherKey = "desvalve";
          }
          //Create an instance of the Cipher
                
          byte key[] = cipherKey.getBytes();
          SecretKeySpec secretKey = new SecretKeySpec(key, "DES");
          Cipher encrypt = null;
                      try {
                            encrypt = Cipher.getInstance("DES/ECB/PKCS5Padding");
                      } catch (NoSuchPaddingException nspe) {
                            throw new PipelineException("Unable to get cipher instance", nspe);
                      } catch (NoSuchAlgorithmException nsae) {
                            throw new PipelineException("Invalid cipher algorithm", nsae);
                      }
                      try {
                            encrypt.init(Cipher.DECRYPT_MODE, secretKey);
                      } catch (InvalidKeyException ike) {
                            throw new PipelineException("Invalid secret key", ike);
                      }

          //original input stream from caller. For example, adapter
          ByteArrayOutputStream bos = new ByteArrayOutputStream();
          try {
 
               encryptStream(inputStreamContext.getInputStream(), bos, encrypt);
          } catch (Exception e) {
               throw new PipelineException("Unable to encrypt", e);
          }
          byte[] bytes = bos.toByteArray();
          InputStream in = new ByteArrayInputStream(bytes);
          //close the input stream passed in this invocation
          inputStreamContext.closeStream();
          //set the input stream and return
          inputStreamContext.setInputStream(in);
          return inputStreamContext;
 
     }
 
     private static void encryptStream(InputStream in, OutputStream out, Cipher encrypt) {
          try {
               byte[] buf = new byte[4096];
               // Bytes written to out will be encrypted
               out = new CipherOutputStream(out, encrypt);
 
               // Read in the cleartext bytes and write to out to encrypt
               int numRead = 0;
               while ((numRead = in.read(buf)) >= 0) {
                    out.write(buf, 0, numRead);
               }
               out.close();
          } catch (java.io.IOException e) {
          }
     }
 
     /*
      * Delete the staging file if there is one
      * (non-Javadoc)
      * @see oracle.tip.pc.services.pipeline.AbstractValve#finalize(oracle.tip.pc.services.pipeline.InputStreamContext)
      */
     public void finalize(InputStreamContext ctx) {
          try {
               cleanup();
          } catch (Exception e) {
          }
     }
 
     /*Use this method to delete the staging file
      * (non-Javadoc)
      * @see oracle.tip.pc.services.pipeline.AbstractStagedValve#cleanup()
      */
     public void cleanup() throws PipelineException, IOException {
 
     }
 
     public static void main(String[] args) throws Exception{
          String cipherKey = "desvalve";
          
          //Create an instance of the Cipher
          byte key[] = cipherKey.getBytes();
          SecretKeySpec secretKey = new SecretKeySpec(key, "DES");
          Cipher encrypt = null;
          try {
               encrypt = Cipher.getInstance("DES/ECB/PKCS5Padding");
          } catch (NoSuchPaddingException nspe) {
               throw new PipelineException("Unable to get cipher instance", nspe);
          } catch (NoSuchAlgorithmException nsae) {
               throw new PipelineException("Invalid cipher algorithm", nsae);
          }
          try {
               encrypt.init(Cipher.ENCRYPT_MODE, secretKey);
          } catch (InvalidKeyException ike) {
               throw new PipelineException("Invalid secret key", ike);
          }
          //original input stream from caller. for example, adapter
          
          FileInputStream fin = new FileInputStream(args[0]);
          FileOutputStream fout = new FileOutputStream(args[1]);
          try {
 
               encryptStream(fin, fout, encrypt);
          } catch (Exception e) {
               throw new PipelineException("Unable to encrypt", e);
          }
          fin.close();
          fout.close();
 
     }
 
}