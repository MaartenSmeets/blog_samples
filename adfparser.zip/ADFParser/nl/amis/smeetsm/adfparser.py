import os
import xml.etree.ElementTree as ET
import re
import copy

path = "C:\\Projects"
adfm_ns = dict(adfmdc='http://adfemg.org/adfm/datacontrol/configuration',adfm='http://xmlns.oracle.com/adfm/configuration',adfmadc='http://xmlns.oracle.com/adfm/datacontrol')
adfdb_ns = dict(adfma='http://xmlns.oracle.com/adfm/application')
adfpd_ns = dict(adfpd='http://xmlns.oracle.com/adfm/uimodel')
adfmi_ns = dict(adfmi='http://xmlns.oracle.com/adfm/metainf')
adfmodelsubdir='adfmsrc'
excluded=os.sep+'classes'+os.sep
adfpagesubdir='public_html'

def get_xpath_element_from_tree(tree,xpath,namespaces):
    return tree.find(xpath, namespaces)

def get_tree_from_xmlfile(filename):
    if os.path.isfile(filename):
        tree = ET.parse(filename)
        return tree
    else:
        return None

def get_xpath_element_from_xmlfile(filename,xpath,namespaces):
    tree = get_tree_from_xmlfile(filename)
    return get_xpath_element_from_tree(tree,xpath, namespaces)

def get_xpath_nodes_from_tree(element,xpath,namespaces):
    return element.findall(xpath, namespaces)

def get_files(filename):
    return_files = []
    for top, dirs, files in os.walk(path):
        for nm in files:
            if nm == filename:
                return_files.append(os.path.join(top, nm))
                #print os.path.join(top, nm)
    return return_files

def parse_models():
    databindings={} #page_method calls
    datacontrol_information = {}
    datacontrol_beans_information = []
    datacontrol_el_information = []
    used_datacontrols=[]
    processed_pagedefs=[]
    for adfmfile in get_files('adfm.xml'):
        #print adfmfile
        adfm_tree=get_tree_from_xmlfile(adfmfile)
        basepath = os.path.dirname(os.path.realpath(adfmfile))
        basepath=os.path.join(basepath,'..'+os.sep+'..')
        
        databinding=get_xpath_element_from_tree(adfm_tree,'./adfmi:DataBindingRegistry',adfmi_ns)
        if databinding != None:
            databindingpath=databinding.attrib.get('path').replace('/',os.sep)
            databindingbasepath=os.path.abspath(os.path.join(basepath,'.'+os.sep+adfmodelsubdir))
            databindingpath=os.path.abspath(os.path.join(databindingbasepath,databindingpath))
            #print "Adding "+databindingpath+" from "+str(adfmfile) +" databindingpath: "+databindingpath
            databindings[copy.copy(databindingpath)]=basepath
            
        datacontrol=get_xpath_element_from_tree(adfm_tree,'./adfmi:DataControlRegistry',adfmi_ns)
        if datacontrol != None:
            datacontrolpath=datacontrol.attrib.get('path').replace('/',os.sep)
            datacontrolbasepath=os.path.abspath(os.path.join(basepath,'.'+os.sep+adfmodelsubdir))
            datacontrolpath=os.path.abspath(os.path.join(datacontrolbasepath,datacontrolpath))
            datacontrol_information=dict(datacontrol_information.items() + parse_xmldatacontrol(datacontrolpath,basepath).items())
            datacontrol_beans_information+=parse_beandatacontrol(datacontrolpath,basepath)
            datacontrol_el_information+=parse_eldatacontrol(datacontrolpath,basepath)
    #for item in datacontrol_information.keys():
    #    print "Datacontrol: "+item
    
    #print datacontrol_beans_information
    

    for databindingkey in databindings.keys(): #pagedefs as present in databindingsfile
        databinding = databindingkey
        basepath=databindings[databindingkey]
        #print "Parsing databinding: "+databinding+" with path "+basepath
        databinding_information=parse_databinding(databinding,basepath) #pagedefs
        for pagedef in databinding_information:
            for methodcall in databinding_information[pagedef]:
                if datacontrol_information.get(methodcall) == None:
                    if methodcall.split('_')[0] in datacontrol_beans_information:
                        None
                        #print "But it is a bean so no problem"
                    elif (methodcall.split('_')[0] in datacontrol_el_information):
                        None
                        #print "But it is a EL datacontrol so no problem"
                    else:
                        print "Method call from pagedef "+pagedef+" not found in datacontrol: "+ methodcall
                else:
                    
                    #print databinding_information.get(page)
                    specific_databinding_information=databinding_information.get(pagedef)
                    if len(specific_databinding_information)>0:
                        if pagedef not in processed_pagedefs and not excluded in pagedef:
                            processed_pagedefs.append(copy.copy(pagedef))
                        
                            print "Page: "+pagedef
                            for databindingitem in specific_databinding_information:
                            
                                used_datacontrols.append(copy.copy(databindingitem))
                                if databindingitem != None and datacontrol_information.get(databindingitem) != None:
                                    for endpointaction in datacontrol_information.get(databindingitem):
                                        print '\tEndpoint: '+endpointaction.get('endpoint')+ " Action: "+endpointaction.get('action')   
    for dc in datacontrol_information.keys():
        if dc not in used_datacontrols:
            print 'DC not used!! '+dc
        
def get_dcusage_from_pagefile(pagefilename):
    #print "Pagefilename: "+pagefilename
    pf_tree = get_tree_from_xmlfile(pagefilename)
    dcusage=[]
    if pf_tree != None:
        methodactions = get_xpath_nodes_from_tree(pf_tree,'.//adfpd:methodAction',adfpd_ns)
        for methodaction in methodactions:
            methodname=methodaction.attrib.get('MethodName')
            methoddc=methodaction.attrib.get('DataControl')
            #print "Data usage in page file: "+methoddc+'_'+methodname
            dcusage.append(methoddc+'_'+methodname)
    return dcusage
            
def parse_databinding(databinding_filename,basepath):
    databinding_file = get_xpath_element_from_xmlfile(databinding_filename,'.',adfdb_ns)
    pages = get_xpath_nodes_from_tree(databinding_file,'./adfma:pageDefinitionUsages/adfma:page',adfdb_ns)
    databindingresult={}
    for page in pages:
        pagefilename=page.attrib.get('path').replace('.',os.sep)+'.xml'
        pagefilebasepath=os.path.abspath(os.path.join(basepath,'.'+os.sep+adfmodelsubdir))
        pagefilepath=os.path.abspath(os.path.join(pagefilebasepath,'.'+os.sep+pagefilename))
        if not os.path.isfile(pagefilepath):
            print "File does not exist: "+pagefilepath
        else:
            #print "Using local file: "+pagefilepath
            databindingresult[pagefilepath]=get_dcusage_from_pagefile(pagefilepath)
    return databindingresult

def parse_beandatacontrol(datacontrol_filename,basepath):
        #print "Datacontrol filename: "+datacontrol_filename
        result = []
        datacontrolxml = get_xpath_element_from_xmlfile(datacontrol_filename,'.',adfm_ns)
        datacontrolnodes = get_xpath_nodes_from_tree(datacontrolxml,'./adfmadc:AdapterDataControl[@ImplDef="oracle.adf.model.adapter.bean.BeanDCDefinition"]',adfm_ns)
        for datacontrolnode in datacontrolnodes:
            datacontrol_id=datacontrolnode.attrib.get('id')
            result.append(copy.copy(datacontrol_id))
        return result

def parse_eldatacontrol(datacontrol_filename,basepath):
        #print "Datacontrol filename: "+datacontrol_filename
        result = []
        datacontrolxml = get_xpath_element_from_xmlfile(datacontrol_filename,'.',adfm_ns)
        datacontrolnodes = get_xpath_nodes_from_tree(datacontrolxml,'./adfmadc:AdapterDataControl[@ImplDef="org.adfemg.datacontrol.xml.DataControlDefinition"]',adfm_ns)
        for datacontrolnode in datacontrolnodes:
            datacontrol_id=datacontrolnode.attrib.get('id')
            for deeplvl_dataprovider in get_xpath_nodes_from_tree(datacontrolnode,'.//adfmdc:data-provider[@class="org.adfemg.datacontrol.xml.provider.data.ELDataProvider"]',adfm_ns):
                result.append(copy.copy(datacontrol_id))
        return result

#fix input. should be absolute path + basepath
def parse_xmldatacontrol(datacontrol_filename,basepath):
        #print "Datacontrol filename: "+datacontrol_filename
        endpointaction_item={}
        endpointaction_array=[]
        result = {}
        datacontrolxml = get_xpath_element_from_xmlfile(datacontrol_filename,'.',adfm_ns)
        datacontrolnodes = get_xpath_nodes_from_tree(datacontrolxml,'./adfmadc:AdapterDataControl[@ImplDef="org.adfemg.datacontrol.xml.DataControlDefinition"]',adfm_ns)
        for datacontrolnode in datacontrolnodes:
            datacontrol_id=datacontrolnode.attrib.get('id')
            #print "Datacontrol id: "+datacontrol_id
            datacontrol_definitions=get_xpath_nodes_from_tree(datacontrolnode,'./adfmadc:Source/adfmdc:definition',adfm_ns)
            
            for datacontrol_definition in datacontrol_definitions:
                if datacontrol_definition != None:
                    endpointaction_array=[]
                    dc_operation=datacontrol_definition.attrib.get('dc-operation')
                    #print "\tDatacontrol dc-operation: "+dc_operation
                    for deeplvl_dataprovider in get_xpath_nodes_from_tree(datacontrol_definition,'.//adfmdc:data-provider[@class="org.adfemg.datacontrol.xml.provider.data.WSDataProvider"]',adfm_ns):
                        #print deeplvl_dataprovider
                        endpoint=get_xpath_element_from_tree(deeplvl_dataprovider,'./adfmdc:parameters/adfmdc:parameter[@name="endPointUrl"]',adfm_ns)
                        #print "\tDatacontrol endpoint: "+endpoint.attrib.get('value')
                        action=get_xpath_element_from_tree(deeplvl_dataprovider,'./adfmdc:parameters/adfmdc:parameter[@name="soapAction"]',adfm_ns)
                        #print "\tDatacontrol soapAction: "+action.attrib.get('value')
                        endpointaction_item['endpoint']=endpoint.attrib.get('value')
                        endpointaction_item['action']=action.attrib.get('value')
                        endpointaction_array.append(copy.copy(endpointaction_item))
                        #print "Setting: "+datacontrol_id+'_'+dc_operation+" to "+ str(endpointaction_item)
                    result[datacontrol_id+'_'+dc_operation]=endpointaction_array
        #print result
        return result
                    
parse_models()