package ms.testapp.soa.utils;

import com.sun.org.apache.xerces.internal.parsers.DOMParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import java.io.StringReader;

import oracle.tip.pc.services.translation.util.ICustomParser;

import org.w3c.dom.Element;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;

import org.apache.http.*;
import org.apache.http.impl.DefaultHttpRequestFactory;
import org.apache.http.impl.entity.EntityDeserializer;
import org.apache.http.impl.entity.LaxContentLengthStrategy;
import org.apache.http.impl.io.AbstractSessionInputBuffer;
import org.apache.http.impl.io.HttpRequestParser;
import org.apache.http.io.HttpMessageParser;
import org.apache.http.io.SessionInputBuffer;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;
import org.apache.http.message.BasicLineParser;
import org.apache.http.params.BasicHttpParams;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import java.io.StringWriter;

import java.io.UnsupportedEncodingException;

import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.util.EntityUtils;

public class HttpRequestReply implements ICustomParser{
    private static String enc = "UTF-8";

    //to display errors
    public static String stackTraceToString(Throwable e) {
        String retValue = null;
        StringWriter sw = null;
        PrintWriter pw = null;
        try {
            sw = new StringWriter();
            pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            retValue = sw.toString();
        } finally {
            try {
                if (pw != null)
                    pw.close();
                if (sw != null)
                    sw.close();
            } catch (IOException ignore) {
                //System.out.println(stackTraceToString(e));
            }
        }
        return retValue;
    }

    //from http://stackoverflow.com/questions/9880117/how-to-convert-a-string-to-an-apache-httpcomponents-httprequest
    public static HttpRequest createHttpRequest(final InputStream in) {
            System.out.println("createHttpRequest");
            try {
                SessionInputBuffer inputBuffer = new AbstractSessionInputBuffer() {
                    {
                        init(in, 10, new BasicHttpParams());
                    }

                    @Override
                    public boolean isDataAvailable(int timeout) throws IOException {
                        throw new RuntimeException("have to override but probably not even called");
                    }
                };
                HttpMessageParser parser = new HttpRequestParser(inputBuffer, new BasicLineParser(new ProtocolVersion("HTTP", 1, 1)), new DefaultHttpRequestFactory(), new BasicHttpParams());
                HttpMessage message = parser.parse();
                if (message instanceof BasicHttpEntityEnclosingRequest) {
                    BasicHttpEntityEnclosingRequest request = (BasicHttpEntityEnclosingRequest) message;
                    EntityDeserializer entityDeserializer = new EntityDeserializer(new LaxContentLengthStrategy());
                    HttpEntity entity = entityDeserializer.deserialize(inputBuffer, message);
                    request.setEntity(entity);
                }
                return (HttpRequest) message;
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (HttpException e) {
                throw new RuntimeException(e);
            }
        }
    
    //from http://stackoverflow.com/questions/11933652/parse-http-request-server-side-using-http-components
    public String getBodyFromHttpRequest(HttpRequest in) {
        System.out.println("getBodyFromHttpRequest");
        String body = "";
        if (in instanceof HttpEntityEnclosingRequest) {
            HttpEntity entity = ((HttpEntityEnclosingRequest) in).getEntity();
            if (entity != null) {
                try {
                    body = EntityUtils.toString(entity, "UTF-8");
                    entity.consumeContent();
                } catch (IOException e) {
                    body = stackTraceToString(e);
                }
            } else {
                System.out.println("HttpRequest entity is empty");
            }
        } else {
            System.out.println("HttpRequest is of class: "+in.getClass().getCanonicalName());
        }
        System.out.println("body: "+body);
        return body;
    }

    //outbound. not using for now
    public Element executeOutbound(InputStream in, OutputStream out, Element payLoad) throws Exception {
        return null;
    }
    
    //inbound request. Inputstream to Element
    public Element executeInboundRequest(InputStream in) throws Exception {
        System.out.println("executeInboundRequest");
        HttpRequest myRequest = createHttpRequest(in);
        String input = getBodyFromHttpRequest(myRequest);
        
        StringBuffer strBuf = new StringBuffer();
        strBuf.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n" + 
        "<process xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" + 
        "         xsi:schemaLocation=\"http://xmlns.oracle.com/JsonExample/HelloWorldBPEL/HelloWorldJsonBPEL xsd/HelloWorldJsonBPEL.xsd\"\n" + 
        "         xmlns=\"http://xmlns.oracle.com/JsonExample/HelloWorldBPEL/HelloWorldJsonBPEL\">\n" + 
        "  <input>");
     
        strBuf.append(input);
        strBuf.append("</input>\n" + 
        "</process>");    
     
        DOMParser parser = new DOMParser();
        parser.parse(new InputSource(new StringReader(strBuf.toString())));
        Element elem = (Element) parser.getDocument().getElementsByTagName(
                "process").item(0);
     
        return elem;
    }

    //below I could have set the headers and then converting them back to  a String
    //using the Apache Http API's for building the entire response and then converting it in one go to a String would have been my preference
    //this however works also and requires less code. the toString method on the request object didn't convert everything to a string
    //so there would have been little benefit in using that method
    public String buildHttpResponse(String content) {
        String retval = "";
        HttpResponse response = new BasicHttpResponse(HttpVersion.HTTP_1_1,200, "OK");
        retval = retval + response.getStatusLine().toString()+"\n";
        retval = retval + "Content-Length: "+Integer.valueOf(content.length()).toString()+"\n";
        retval = retval + "Content-Type: "+"application/json; charset=UTF-8"+"\n\n";
        retval = retval + content;
        return retval;
    }

    //inboundreply (sync call). Element to outputstream
    public void executeInboundReply(Element payLoad, OutputStream out) throws Exception {
        System.out.println("executeInboundReply");
        BasicHttpResponse myResp = null;
        PrintWriter out1 = new PrintWriter(new OutputStreamWriter(out));
        NodeList list = payLoad.getChildNodes();
        String retVal = "";
        for(int i = 0; i < list.getLength(); i++) {
            Node node = list.item(i);
            NodeList list1 = node.getChildNodes();
            for(int j = 0; j < list1.getLength(); j++) {
                Node node1 = list1.item(j);
                if(node1.getNodeType() == Node.TEXT_NODE) {
                        System.out.println("Textnode found with value: "+node1.getNodeValue());
                        retVal = retVal + node1.getNodeValue();
                }
            }
            
        }
        System.out.println("executeInboundReply result String: "+retVal);
        System.out.println("executeInboundReply result Http request: "+buildHttpResponse(retVal));
        out1.println(buildHttpResponse(retVal));
        out1.flush();
    }
}
