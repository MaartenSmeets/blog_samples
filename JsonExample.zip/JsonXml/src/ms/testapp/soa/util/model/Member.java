
package ms.testapp.soa.util.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.xmlsh.org/jxml}value"/>
 *       &lt;/sequence>
 *       &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "value" })
@XmlRootElement(name = "member")
public class Member {

  @XmlElementRef(name = "value", namespace = "http://www.xmlsh.org/jxml",
                 type = JAXBElement.class)
  protected JAXBElement<?> value;
  @XmlAttribute(required = true)
  @XmlSchemaType(name = "anySimpleType")
  protected String name;

  /**
   * Gets the value of the value property.
   *
   * @return
   *     possible object is
   *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
   *     {@link JAXBElement }{@code <}{@link Array }{@code >}
   *     {@link JAXBElement }{@code <}{@link Null }{@code >}
   *     {@link JAXBElement }{@code <}{@link String }{@code >}
   *     {@link JAXBElement }{@code <}{@link nl.mineleni.egeo.Object }{@code >}
   *     {@link JAXBElement }{@code <}{@link Double }{@code >}
   *     {@link JAXBElement }{@code <}{@link java.lang.Object }{@code >}
   *
   */
  public JAXBElement<?> getValue() {
    return value;
  }

  /**
   * Sets the value of the value property.
   *
   * @param value
   *     allowed object is
   *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
   *     {@link JAXBElement }{@code <}{@link Array }{@code >}
   *     {@link JAXBElement }{@code <}{@link Null }{@code >}
   *     {@link JAXBElement }{@code <}{@link String }{@code >}
   *     {@link JAXBElement }{@code <}{@link nl.mineleni.egeo.Object }{@code >}
   *     {@link JAXBElement }{@code <}{@link Double }{@code >}
   *     {@link JAXBElement }{@code <}{@link java.lang.Object }{@code >}
   *
   */
  public void setValue(JAXBElement<?> value) {
    this.value = ((JAXBElement<?>)value);
  }

  /**
   * Gets the value of the name property.
   *
   * @return
   *     possible object is
   *     {@link String }
   *
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the value of the name property.
   *
   * @param value
   *     allowed object is
   *     {@link String }
   *
   */
  public void setName(String value) {
    this.name = value;
  }

}
