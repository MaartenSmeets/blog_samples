
package ms.testapp.soa.util.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import ms.testapp.soa.util.model.Array;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the nl.mineleni.egeo package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _Object_QNAME =
    new QName("http://www.xmlsh.org/jxml", "object");
  private final static QName _Number_QNAME =
    new QName("http://www.xmlsh.org/jxml", "number");
  private final static QName _Boolean_QNAME =
    new QName("http://www.xmlsh.org/jxml", "boolean");
  private final static QName _Value_QNAME =
    new QName("http://www.xmlsh.org/jxml", "value");
  private final static QName _Array_QNAME =
    new QName("http://www.xmlsh.org/jxml", "array");
  private final static QName _Null_QNAME =
    new QName("http://www.xmlsh.org/jxml", "null");
  private final static QName _String_QNAME =
    new QName("http://www.xmlsh.org/jxml", "string");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: nl.mineleni.egeo
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link Member }
   *
   */
  public Member createMember() {
    return new Member();
  }

  /**
   * Create an instance of {@link ms.testapp.soa.util.model.Object }
   *
   */
  public ms.testapp.soa.util.model.Object createObject() {
    return new ms.testapp.soa.util.model.Object();
  }

  /**
   * Create an instance of {@link Null }
   *
   */
  public Null createNull() {
    return new Null();
  }

  /**
   * Create an instance of {@link Array }
   *
   */
  public Array createArray() {
    return new Array();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link ms.testapp.soa.util.model.Object }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "object",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<ms.testapp.soa.util.model.Object> createObject(ms.testapp.soa.util.model.Object value) {
    return new JAXBElement<ms.testapp.soa.util.model.Object>(_Object_QNAME,
                                                    ms.testapp.soa.util.model.Object.class,
                                                    null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "number",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<Double> createNumber(Double value) {
    return new JAXBElement<Double>(_Number_QNAME, Double.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "boolean",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<Boolean> createBoolean(Boolean value) {
    return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null,
                                    value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.Object }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "value")
  public JAXBElement<java.lang.Object> createValue(java.lang.Object value) {
    return new JAXBElement<java.lang.Object>(_Value_QNAME,
                                             java.lang.Object.class, null,
                                             value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Array }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "array",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<Array> createArray(Array value) {
    return new JAXBElement<Array>(_Array_QNAME, Array.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Null }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "null",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<Null> createNull(Null value) {
    return new JAXBElement<Null>(_Null_QNAME, Null.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "http://www.xmlsh.org/jxml", name = "string",
                  substitutionHeadNamespace = "http://www.xmlsh.org/jxml",
                  substitutionHeadName = "value")
  public JAXBElement<String> createString(String value) {
    return new JAXBElement<String>(_String_QNAME, String.class, null, value);
  }

}
