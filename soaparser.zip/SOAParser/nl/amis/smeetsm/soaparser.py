import os
import xml.etree.ElementTree as ET
import re

path = "C:\\JDeveloper\\mywork\\SOAApplication"
sca_ns = dict(sca='http://xmlns.oracle.com/sca/1.0')
jca_ns = dict(jca='http://platform.integration.oracle/blocks/adapter/fw/metadata')
bpel20_ns = dict(bpel='http://docs.oasis-open.org/wsbpel/2.0/process/executable')
bpmn20_ns = dict(bpmn20='http://xmlns.oracle.com/bpm/OracleExtensions')

def substring_after(s, delim):
    return s.partition(delim)[2]

def wsdl_to_servicename(wsdl):
    withoutwsdl=wsdl.replace('?wsdl','').replace('?WSDL','')
    strlist = withoutwsdl.split('/')
    grp2=strlist[len(strlist)-1]
    grp1=strlist[len(strlist)-2]
    
    if '.' in grp2:
        version=grp2
        service=grp1
        complete_servicename=grp1+'_'+grp2
    else:
        complete_servicename=grp1
    
    return complete_servicename
    #stuff/stuff/stuff
    

def get_composite_filenames():
    composites = []
    for top, dirs, files in os.walk(path):
        for nm in files:
            if nm == 'composite.xml':
                composites.append(os.path.join(top, nm))
                #print os.path.join(top, nm)
    return composites

def get_xpath_element_from_tree(tree,xpath,namespaces):
    return tree.find(xpath, namespaces),'Succes',1

def get_tree_from_xmlfile(filename):
    if os.path.isfile(filename):
        tree = ET.parse(filename)
        return tree,'Succes',1
    else:
        return None,'File not found',0

def get_xpath_element_from_xmlfile(filename,xpath,namespaces):
    tree,msg,status = get_tree_from_xmlfile(filename)
    return get_xpath_element_from_tree(tree,xpath, namespaces)

def get_xpath_nodes_from_tree(element,xpath,namespaces):
    return element.findall(xpath, namespaces)

def get_jca_property(jcatree,property_name):
    property_xpath = "jca:endpoint-interaction/jca:interaction-spec/jca:property[@name='"+property_name+"']"
    property,msg,status = get_xpath_element_from_tree(jcatree,property_xpath,jca_ns)
    return property.attrib.get('value')

def parse_jca_dbstoredprocedure_reference(jcatree):
    try:
        SchemaName = get_jca_property(jcatree,'SchemaName')
    except AttributeError as e:
        SchemaName = None
    try:
        PackageName = get_jca_property(jcatree,'PackageName')
    except AttributeError as e:
        PackageName = None
        
    ProcedureName = get_jca_property(jcatree,'ProcedureName')

    if (SchemaName != None):
        CompleteName = SchemaName + '.' + PackageName + '.' + ProcedureName
    else:
        if PackageName != None:
            CompleteName = PackageName + '.' + ProcedureName
        else:
            CompleteName = ProcedureName
    return CompleteName

def namespace(element):
    m = re.match('\{.*\}', element.tag)
    return m.group(0) if m else ''

def source_uri_localref(sourceuri):
    return sourceuri.split('/',1)[1].replace('.reference','')

def get_bpel20_partnerlinks(bpel_tree,reference_name):
    return get_xpath_nodes_from_tree(bpel_tree,'bpel:partnerLinks/bpel:partnerLink[@name="'+reference_name+'"]',bpel20_ns)

#needed because [[]] didn't work (SyntaxError: invalid predicate)
def get_bpmn20_service_from_conversation(conversation):
    conversation_xpath = './bpmn20:ServiceCallConversationDefinition'
    conversation_element,msg,status=get_xpath_element_from_tree(conversation,conversation_xpath,bpmn20_ns)
    if conversation_element != None:
        return conversation_element.attrib.get('service')
    else:
        return None

def get_bpel20_invokes(bpel_tree,partnerlink_name):
    return get_xpath_nodes_from_tree(bpel_tree,'.//bpel:invoke[@partnerLink="'+partnerlink_name+'"]',bpel20_ns)

def parse_component_for_operation(component_tree,reference_name,sourceuri,basepath):
    component_version=component_tree.attrib.get('version')
    implementation_bpel,msg,status = get_xpath_element_from_tree(component_tree,'sca:implementation.bpel',sca_ns)
    implementation_bpmn,msg,status = get_xpath_element_from_tree(component_tree,'sca:implementation.bpmn',sca_ns)
    implementation_mediator,msg,status = get_xpath_element_from_tree(component_tree,'sca:implementation.mediator',sca_ns)
    implementation_workflow,msg,status = get_xpath_element_from_tree(component_tree,'sca:implementation.workflow',sca_ns)
    #print "\t\tReference name: "+reference_name
    if (implementation_bpel != None and component_version=='2.0'):
        bpel = implementation_bpel.attrib.get('src')
        bpel_osindependant = bpel.replace('/',os.sep)
        bpel_absolutepath = os.path.join(basepath,bpel_osindependant)
        #print "\tBPEL file: "+bpel_absolutepath
        bpel_tree,msg,status = get_tree_from_xmlfile(bpel_absolutepath)
        for partnerlink in get_bpel20_partnerlinks(bpel_tree,reference_name):
            #print "Partnerlink: "+str(partnerlink)
            for invoke in get_bpel20_invokes(bpel_tree,partnerlink.attrib.get('name')):
                #print '\t\tBPEL process. Operation called: '+str(invoke.attrib.get('operation'))
                print '\t\t'+str(invoke.attrib.get('operation'))
    elif (implementation_bpmn != None):
        bpmn = implementation_bpmn.attrib.get('src')
        bpmn_osindependant = bpmn.replace('/',os.sep)
        bpmn_absolutepath = os.path.join(basepath,bpmn_osindependant)        
        #print "\t\tBPMN: "+bpmn_absolutepath
        bpmn_tree,msg,status = get_tree_from_xmlfile(bpmn_absolutepath)
        bpmn_localref = source_uri_localref(sourceuri.text)
        for conversation in get_xpath_nodes_from_tree(bpmn_tree,'.//bpmn20:Conversations/bpmn20:Conversation',bpmn20_ns):
            service=str(get_bpmn20_service_from_conversation(conversation))
            if (service==bpmn_localref):
                #this is a correct conversation
                conversationalnodes=get_xpath_nodes_from_tree(bpmn_tree,'.//bpmn20:Conversational/[@conversation="'+conversation.attrib.get('id')+'"]',bpmn20_ns)
                for conversationalnode in conversationalnodes:
                    servicecalldef,msg,status=get_xpath_element_from_tree(conversationalnode,'bpmn20:ServiceCallConversationalDefinition',bpmn20_ns)
                    #print "\t\tOperation: "+servicecalldef.attrib.get('operation')
                    print "\t\t"+servicecalldef.attrib.get('operation')
                #Conversational conversation="CONVERSATION107125384349"
                #print "\t\tUse this service: "+service
        #print source_uri_localref(sourceuri.text)
        #get part after / from sourceuri
    elif (implementation_mediator != None):
        None
        #print '\t\tMediator: '+str(implementation_mediator.attrib.get('src'))
    elif (implementation_workflow != None):
        None
        #print '\t\tTask: '+str(implementation_mediator.attrib.get('src'))
    else:
        None
        #print '\t\tUnsupported component. Operation cannot be determined'

def parse_jca_ws(compxml,reference_tree,basepath):
    #http://xmlns.oracle.com/pcbpel/adapter/db/SOAApplication/HelloWorldDb/GetSysdatedbReference#wsdl.interface(GetSysdatedbReference_ptt)
    #determine reference name
    #search wires to determine relevant components
    #parse components for operation
    reference_name = reference_tree.attrib.get('name')
    #print "\tReference name: "+str(reference_name)
    wirexpath = "sca:wire[sca:target.uri='"+reference_name+"']"+'/sca:source.uri'
    #print wirexpath
    for sourceuri in get_xpath_nodes_from_tree(compxml,wirexpath,sca_ns):
        component_name = sourceuri.text.split('/')[0]
        component_xpath='sca:component[@name="'+component_name+'"]'
        component_tree,msg,status=get_xpath_element_from_tree(compxml,component_xpath,sca_ns)
        parse_component_for_operation(component_tree,reference_name,sourceuri,basepath)

def parse_reference(compxml,reference,basepath):
    bindingjca,msg,status = get_xpath_element_from_tree(reference,'sca:binding.jca',sca_ns)
    bindingws,msg,status = get_xpath_element_from_tree(reference,'sca:binding.ws',sca_ns)

    if bindingjca != None:
        jcafile=bindingjca.attrib.get('config')
        jcafile_osindependant = jcafile.replace('/',os.sep)
        jcafile_absolutepath = os.path.join(basepath,jcafile_osindependant)
        #print '\tJCA file: '+jcafile_absolutepath
        
        try:
            jcatree,msg,status = get_xpath_element_from_xmlfile(jcafile_absolutepath,'.',jca_ns)
        except AttributeError:
            status=0
            
        if status!=0:
            interaction_spec,msg,status = get_xpath_element_from_tree(jcatree,'jca:endpoint-interaction/jca:interaction-spec',jca_ns)
            interactionspec_classname = interaction_spec.attrib.get('className')
            #print interactionspec_classname
            if interactionspec_classname =='oracle.tip.adapter.db.DBStoredProcedureInteractionSpec':
                #print "\tDatabase stored procedure call: "+str(parse_jca_dbstoredprocedure_reference(jcatree))
                print "\t"+str(parse_jca_dbstoredprocedure_reference(jcatree))
            else:
                None
                #print '\tUnsupported JCA binding'
    elif (bindingws != None):
        service_wsdl = bindingws.attrib.get('location')
        #print "\tWSDL location: "+str(service_wsdl)
        print "\t"+wsdl_to_servicename(str(service_wsdl))
        parse_jca_ws(compxml,reference,basepath)
    else:
        print 'Unsupported reference'

def parse_composites():
    composites = get_composite_filenames()
    for composite in composites:
        compxml,msg,status = get_xpath_element_from_xmlfile(composite,'.',sca_ns)
        #print 'Composite: '+compxml.attrib.get('name')
        print compxml.attrib.get('name')
        for reference in get_xpath_nodes_from_tree(compxml,'sca:reference',sca_ns):
            basepath = os.path.dirname(os.path.realpath(composite))
            #print basepath
            parse_reference(compxml,reference,basepath)

parse_composites()