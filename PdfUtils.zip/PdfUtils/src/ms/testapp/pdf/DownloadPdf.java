package ms.testapp.pdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.io.InputStream;

import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DownloadPdf extends HttpServlet {
  private static final long serialVersionUID = 4537516508557609572L;

  public DownloadPdf() {
    super();
  }
  
  public void doGet(HttpServletRequest request, HttpServletResponse response)  
  throws ServletException, IOException, FileNotFoundException  {  
     
   //ServletContext ctx = getServletContext();  
   //System.out.println("1");
   System.out.println("parameter filename: "+request.getParameter("filename"));
   long length = new File(request.getParameter("filename")).length();
   System.out.println("size: "+length);
   InputStream is = new FileInputStream(new File(request.getParameter("filename")));  
   //System.out.println("2");
   
   response.addHeader("content-disposition", "attachment; filename=mypdf.pdf;");
 
   //System.out.println("3");
   response.setContentType("application/pdf");
   response.setContentLength(Long.valueOf(length).intValue());
   //System.out.println("4");
   int read =0;  
   byte[] bytes = new byte[1024];
   //System.out.println("5");
   OutputStream os = response.getOutputStream();  
   //System.out.println("6");
   while((read = is.read(bytes)) != -1)  
   { //System.out.println("7");  
   os.write(bytes, 0, read);  
   }  
   os.flush();  
   os.close();  
  }  
}
