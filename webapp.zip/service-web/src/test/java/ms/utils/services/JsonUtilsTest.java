/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.services;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.servlet.http.HttpServletRequest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author maarten
 */
public class JsonUtilsTest {
    
    public JsonUtilsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of HTTPrequestToJsonNode method, of class JsonUtils.
     */
    @Test
    public void testHTTPrequestToJsonNode() {
        System.out.println("HTTPrequestToJsonNode");
    }

    /**
     * Test of JsonNodeToString method, of class JsonUtils.
     */
    @Test
    public void testJsonNodeToString() throws Exception {
        System.out.println("JsonNodeToString");
        String jsoninput = "{\"k1\":\"v1\"}";
        JsonUtils instance = new JsonUtils();
        
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser jp = factory.createJsonParser(jsoninput);
        JsonNode testNode = mapper.readTree(jp);
        
        String expResult = jsoninput;
        String result = instance.JsonNodeToString(testNode);
        
        assertEquals(expResult, result);
        assertTrue(instance.JsonNodeToString(instance.StringToJsonNode(jsoninput)).equals(jsoninput));
    }

    /**
     * Test of StringToJsonNode method, of class JsonUtils.
     */
    @Test
    public void testStringToJsonNode() throws Exception {
        System.out.println("StringToJsonNode");
        String jsoninput = "{\"k1\":\"v1\"}";
        JsonUtils instance = new JsonUtils();
        
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser jp = factory.createJsonParser(jsoninput);
        
        JsonNode expResult = mapper.readTree(jp);
        JsonNode result = instance.StringToJsonNode(jsoninput);
        assertEquals(expResult, result);
        assertTrue(instance.JsonNodeToString(instance.StringToJsonNode(jsoninput)).equals(jsoninput));
    }
}
