/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.webapp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import ms.utils.model.Dice;
import ms.utils.model.Message;
import ms.utils.model.MessageComparator;
import ms.utils.model.MessageFacade;
import ms.utils.model.Parameter;
import ms.utils.model.ParameterFacade;
import org.primefaces.push.PushContext;
import org.primefaces.push.PushContextFactory;

/**
 *
 * @author maarten
 */
@ManagedBean(name = "messageBean")
@SessionScoped
public class messageBean implements Serializable {

    private Dice myDice = new Dice();
    private Integer dicetype = 0;
    private Integer bonusperdice = 0;
    private Integer bonustotal = 0;
    private Integer amountofdice = 1;
    private SelectItem[] diceSelect = new SelectItem[]{new SelectItem(new String("4"), "d4"),
        new SelectItem(new String("6"), "d6"),
        new SelectItem(new String("8"), "d8"),
        new SelectItem(new String("10"), "d10"),
        new SelectItem(new String("12"), "d12"),
        new SelectItem(new String("20"), "d20"),
        new SelectItem(new String("100"), "d100")
    };
    private String newname = "";
    private String newtext = "";
    private List<Message> messages = new ArrayList<Message>();
    @EJB
    private MessageFacade messageFacade;

    /**
     * Creates a new instance of messageBean
     */
    public messageBean() {
    }

    static messageBean getInstance() {
        FacesContext context = FacesContext.getCurrentInstance();
        messageBean mybean = (messageBean) context.getExternalContext().getSessionMap().get("messageBean");
        return mybean;
    }

    public String addAction() {
        messageFacade.create(new Message(this.getNewname(), this.getNewtext()));
        doPushUpdate();
        loadMessages();
        return null;
    }

    private void doPushUpdate() {
        PushContext pushContext = PushContextFactory.getDefault().getPushContext();
        pushContext.push("/messages", "update");
    }

    @PostConstruct
    public void loadMessages() {
        messages = messageFacade.findAll();
        Collections.sort(messages, new MessageComparator());
    }

    /**
     * @return the newname
     */
    public String getNewname() {
        return newname;
    }

    /**
     * @param newname the newname to set
     */
    public void setNewname(String newname) {
        this.newname = newname;
    }

    /**
     * @return the newtext
     */
    public String getNewtext() {
        return newtext;
    }

    /**
     * @param newtext the newtext to set
     */
    public void setNewtext(String newtext) {
        this.newtext = newtext;
    }

    /**
     * @return the messages
     */
    public List<Message> getMessages() {
        return messages;
    }

    /**
     * @param messages the messages to set
     */
    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    /**
     * @return the dicetype
     */
    public Integer getDicetype() {
        return dicetype;
    }

    /**
     * @param dicetype the dicetype to set
     */
    public void setDicetype(Integer dicetype) {
        this.dicetype = dicetype;
    }

    /**
     * @return the bonusperdice
     */
    public Integer getBonusperdice() {
        return bonusperdice;
    }

    /**
     * @param bonusperdice the bonusperdice to set
     */
    public void setBonusperdice(Integer bonusperdice) {
        this.bonusperdice = bonusperdice;
    }

    /**
     * @return the bonustotal
     */
    public Integer getBonustotal() {
        return bonustotal;
    }

    /**
     * @param bonustotal the bonustotal to set
     */
    public void setBonustotal(Integer bonustotal) {
        this.bonustotal = bonustotal;
    }

    /**
     * @return the amountofdice
     */
    public Integer getAmountofdice() {
        return amountofdice;
    }

    /**
     * @param amountofdice the amountofdice to set
     */
    public void setAmountofdice(Integer amountofdice) {
        this.amountofdice = amountofdice;
    }

    /**
     * @return the diceSelect
     */
    public SelectItem[] getDiceSelect() {
        return diceSelect;
    }

    /**
     * @param diceSelect the diceSelect to set
     */
    public void setDiceSelect(SelectItem[] diceSelect) {
        this.diceSelect = diceSelect;
    }

    public void rollDice() {
        setNewtext(myDice.rollMultiple(dicetype, bonusperdice, amountofdice, bonustotal));
        addAction();
        setNewtext("");
    }

    public void processDiceTypeSelectionChange(ValueChangeEvent ev) {
        setDicetype((Integer) ev.getNewValue());
    }
}
