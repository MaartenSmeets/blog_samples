/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.webapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import ms.utils.model.Parameter;

import ms.utils.model.ParameterFacade;

/**
 *
 * @author maarten
 */
@ManagedBean(name = "parametersBean")
@SessionScoped
public class parametersBean {

    private String newname = "";
    private String newvalue = "";
    private List<Parameter> parameters;
    
    @EJB
    private ParameterFacade parameterFacade;
    
    static parametersBean getInstance() {
        FacesContext context = FacesContext.getCurrentInstance();
        parametersBean mybean =  (parametersBean) context.getExternalContext().getSessionMap().get("parametersBean");
        return mybean;
    }
    
    public void loadParameters() {
        parameters = new ArrayList<Parameter>();
        parameters.addAll(parameterFacade.getParameterByGroupident("Common"));
    }
    
    /**
     * Creates a new instance of parametersBean
     */
    public parametersBean() {
        //loadParameters();
    }

    public String addAction() {
        Parameter myparam = parameterFacade.getParameterByName("Common", newname);
        if (myparam == null) {
            parameterFacade.create(new Parameter("Common",this.newname, this.newvalue));
        } else {
            parameterFacade.edit(new Parameter("Common",this.newname, this.newvalue));
        }
        loadParameters();
        return null;
    }
    
    public void removeAction(Long id) {
      parameterFacade.remove(parameterFacade.find(id));
      loadParameters();
   }

    /**
     * @return the newname
     */
    public String getNewname() {
        return newname;
    }

    /**
     * @param newname the newname to set
     */
    public void setNewname(String newname) {
        this.newname = newname;
    }

    /**
     * @return the newvalue
     */
    public String getNewvalue() {
        return newvalue;
    }

    /**
     * @param newvalue the newvalue to set
     */
    public void setNewvalue(String newvalue) {
        this.newvalue = newvalue;
    }

    /**
     * @return the parameters
     */
    public List<Parameter> getParameters() {
        return parameters;
    }

    /**
     * @param parameters the parameters to set
     */
    public void setParameters(List<Parameter> parameters) {
        this.parameters = parameters;
    }
}
