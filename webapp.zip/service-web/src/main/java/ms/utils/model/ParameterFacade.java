/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author maarten
 */
@Stateless
public class ParameterFacade extends AbstractFacade<Parameter> {

    @PersistenceContext(unitName = "ms.utils_service-web_war_1.0-SNAPSHOTPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ParameterFacade() {
        super(Parameter.class);
    }

    public List<Parameter> getParameterByGroupident(String groupident) {
        TypedQuery<Parameter> query = em.createQuery(
                "SELECT c FROM Parameter c WHERE c.groupident = :groupident", Parameter.class);
        return query.setParameter("groupident", groupident).getResultList();
    }

    public Parameter getParameterByName(String groupident, String name) {
        TypedQuery<Parameter> query = em.createQuery(
                "SELECT c FROM Parameter c WHERE c.groupident = :groupident AND c.name=:name", Parameter.class);
        query.setParameter("groupident", groupident);
        query.setParameter("name", name);
        Parameter result;
        try {
            result = query.getSingleResult();
        } catch (javax.persistence.NoResultException e) {
            result = null;
        }

        return result;
    }
}
