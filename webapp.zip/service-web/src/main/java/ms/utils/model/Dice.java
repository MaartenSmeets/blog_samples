/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.model;

import java.util.Random;

/**
 *
 * @author maarten
 */
public class Dice {

    Random r = new Random();

    public Integer rollSingle(Integer diceType) {
        return r.nextInt(diceType) + 1;
    }

    public String rollMultiple(Integer diceType, Integer bonusPerDice, Integer amount, Integer totalBonus) {
        String result = "";
        Integer singleResult = 0;
        Integer total = 0;
        for (int counter = 0; counter < amount; counter++) {
            singleResult = rollSingle(diceType);
            total = total + singleResult + bonusPerDice;
            if (result.equals("")) {
                result = result + "1d" + diceType + "(" + String.valueOf(singleResult) + ")";
            } else {
                result = result + " + 1d" + diceType + "(" + String.valueOf(singleResult) + ")";
            }
            if (bonusPerDice != 0) {
                result = result + " + " + bonusPerDice.toString();
            }
        }
        if (totalBonus != 0) {
            result = result + " + " + totalBonus.toString();
            total = total + totalBonus;
        }
        result = result + " = " + String.valueOf(total);
        return result;

    }
}
