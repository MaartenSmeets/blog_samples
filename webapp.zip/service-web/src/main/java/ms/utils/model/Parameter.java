/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.model;

import java.io.Serializable;
import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author maarten
 */
@Entity
public class Parameter implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String groupident;
    private String name;
    private String value;

    public Parameter() {
        super();
    }
    
    public Parameter(String groupident,String name,String value) {
        this.groupident=groupident;
        this.name=name;
        this.value=value;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Parameter)) {
            return false;
        }
        Parameter other = (Parameter) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        if (!this.getName().equals(other.getName())) {
            return false;
        }
        if (!this.getValue().equals(other.getValue())) {
            return false;
        }
        if (!this.getGroupident().equals(other.getGroupident())) {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return "ms.utils.model.parameter[ id=" + id + " groupident="+groupident+ " name="+name+ " value="+value+" ]";
    }

    /**
     * @return the groupident
     */
    public String getGroupident() {
        return groupident;
    }

    /**
     * @param groupident the groupident to set
     */
    public void setGroupident(String groupident) {
        this.groupident = groupident;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    
}
