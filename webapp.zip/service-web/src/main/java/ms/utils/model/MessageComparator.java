/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.model;

import java.util.Comparator;

/**
 *
 * @author maarten
 */
public class MessageComparator implements Comparator<Message>{
    @Override
    public int compare(Message o1, Message o2) {
        return o2.getTimestmp().compareTo(o1.getTimestmp());
    }
}
