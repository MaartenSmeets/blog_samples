/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ms.utils.services;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author maarten
 */
public class JsonUtils {
    Logger logger = Logger.getLogger(this.getClass().getName());
    
    public JsonNode HTTPrequestToJsonNode(HttpServletRequest request) {
        Enumeration<String> myParams = request.getParameterNames();
        String param = "";
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode on = mapper.createObjectNode();
        while (myParams.hasMoreElements()) {
            param = myParams.nextElement();
            on = mapper.createObjectNode();
            on.put(param,request.getParameter(param));
            logger.info("Set parameter: "+param+" Value: "+request.getParameter(param));
        }
        return on;
    }
    
    public String JsonNodeToString(JsonNode input) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(input);
    }
    
    public JsonNode StringToJsonNode(String jsoninput) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser jp = factory.createJsonParser(jsoninput);
        return mapper.readTree(jp);
    }
    
}
