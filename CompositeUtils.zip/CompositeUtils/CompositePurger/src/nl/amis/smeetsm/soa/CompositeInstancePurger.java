package nl.amis.smeetsm.soa;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.naming.Context;

import oracle.soa.management.facade.Composite;
import oracle.soa.management.facade.CompositeInstance;
import oracle.soa.management.facade.Locator;
import oracle.soa.management.facade.LocatorFactory;
import oracle.soa.management.util.CompositeFilter;
import oracle.soa.management.util.CompositeInstanceFilter;

import org.joda.time.DateTime;

public class CompositeInstancePurger {
    public CompositeInstancePurger() {
        super();
    }

    public static Locator getLocator(String providerURL, String user, String pass) throws Exception {
        Hashtable jndiProps = new Hashtable();
        jndiProps.put(Context.PROVIDER_URL, providerURL);
        jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
        jndiProps.put(Context.SECURITY_PRINCIPAL, user);
        jndiProps.put(Context.SECURITY_CREDENTIALS, pass);
        jndiProps.put("dedicated.connection", "true");
        return LocatorFactory.createLocator(jndiProps);
    }

    public static List<Composite> getComposites(Locator myLocator) throws Exception {
        CompositeFilter filter = new CompositeFilter();
        return myLocator.getComposites(filter);
    }

    public static CompositeInstanceFilter getCompositeInstanceFilter() {
        CompositeInstanceFilter filter = new CompositeInstanceFilter();
        int[] states = {
            CompositeInstance.STATE_COMPLETED_SUCCESSFULLY, CompositeInstance.STATE_FAULTED,
            CompositeInstance.STATE_STALE, CompositeInstance.STATE_SUSPENDED,
            CompositeInstance.STATE_TERMINATED_BY_USER, CompositeInstance.STATE_UNKNOWN
        };
        filter.setStates(states);
        Date daysAgo = new DateTime(new Date()).minusDays(1).toDate();
        filter.setMaxCreationDate(daysAgo);
        return filter;
    }

    static void purgeInstances(Locator myLocator) throws Exception {
        ExecutorService myExecutor = Executors.newFixedThreadPool(10);
        try {
            List<Composite> composites = getComposites(myLocator);
            System.out.println("Composites: " + composites.size());
            for (Composite myComposite : composites) {
                System.out.println("Processing: " + myComposite.getCompositeDN().toString() + " instances " +
                                   myComposite.getInstanceCount());
                try {
                    Runnable myRunnable =
                        new CompositeInstancePurgerRunnable(myComposite, getCompositeInstanceFilter());
                    myExecutor.execute(myRunnable);
                } catch (Exception e) {
                    System.out.println("\tError during purge instances: " + getStacktrace(e));
                }
            }
        } catch (Exception e) {
            System.out.println("\tError during list composites: " + getStacktrace(e));
        }
        myExecutor.shutdown();

    }

    public static String getStacktrace(Throwable e) {
        StringWriter sw = new StringWriter();
        new Throwable("").printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    public static void main(String[] args) throws Exception {
        Locator myLocator = null;
        myLocator = getLocator("t3://localhost:7101/soa-infra", "weblogic", "Welcome01");
        purgeInstances(myLocator);
    }
}
