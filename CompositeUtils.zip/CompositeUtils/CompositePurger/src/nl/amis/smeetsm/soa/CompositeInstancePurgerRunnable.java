package nl.amis.smeetsm.soa;

import oracle.soa.management.facade.Composite;
import oracle.soa.management.util.CompositeInstanceFilter;

public class CompositeInstancePurgerRunnable implements Runnable {
    private Composite composite = null;
    private CompositeInstanceFilter compositeinstancefilter = null;

    public CompositeInstancePurgerRunnable(Composite composite, CompositeInstanceFilter compositeinstancefilter) {
        super();
        this.setCompositeInstancFilter(compositeinstancefilter);
        this.setComposite(composite);
    }

    @Override
    public void run() {
        try {
            getComposite().purgeInstances(getCompositeInstanceFilter());
        } catch (Exception e) {
            System.out.println("\tPurge instances failed in Runnable class for: " +
                               getComposite().getCompositeDN().toString());
        }
    }

    public Composite getComposite() {
        return composite;
    }

    public void setComposite(Composite composite) {
        this.composite = composite;
    }

    public CompositeInstanceFilter getCompositeInstanceFilter() {
        return compositeinstancefilter;
    }

    public void setCompositeInstancFilter(CompositeInstanceFilter compositeinstancefilter) {
        this.compositeinstancefilter = compositeinstancefilter;
    }
}
