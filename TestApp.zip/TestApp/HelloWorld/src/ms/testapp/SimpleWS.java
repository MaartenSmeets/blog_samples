package ms.testapp;

import javax.jws.WebService;

@WebService
public class SimpleWS {
    public SimpleWS() {
        super();
    }
    
    public String sayHello(String name) {
        return "Hello "+name;
    }
}
