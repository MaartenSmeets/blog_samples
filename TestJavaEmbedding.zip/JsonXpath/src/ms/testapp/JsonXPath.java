package ms.testapp;

import com.jayway.jsonpath.JsonPath;

import java.util.List;

import oracle.fabric.common.xml.xpath.IXPathContext;
import oracle.fabric.common.xml.xpath.XPathFunctionException;
import org.w3c.dom.Node;



public class JsonXPath  implements oracle.fabric.common.xml.xpath.IXPathFunction{
  public JsonXPath() {
    super();
  }

  public Object call(IXPathContext context, List args) throws XPathFunctionException {
    if (args.size() == 2)
    {
    String jsonpath = getValue(args.get(1)); 
    String jsonstring = getValue(args.get(0)); 
    //org.w3c.dom.Node node = (org.w3c.dom.Node) args.get(0);
    return JsonPath.read(jsonstring, jsonpath).toString();
    }
    return "";
  }
  
  /**
   * Extract the value of our String.
   * 
   * @param o object
   * @return a string which contains our value
   * @throws XPathFunctionException if error occurs
   */
  private String getValue(Object o) throws XPathFunctionException {
    if (o instanceof String) {
      return ((String) o);
    } else if (o instanceof Node) {
      return ((Node) o).getTextContent();
    } else {
      throw new XPathFunctionException("Unknown argument type.");
    }
  }
}
