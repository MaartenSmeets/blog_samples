package ms.testapp;

import com.jayway.jsonpath.JsonPath;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService
public class JsonPathUtils {
    
    @WebResult(name = "result")
    public String ExecuteJsonPath(@WebParam(name = "jsonstring") String jsonstring, @WebParam(name = "jsonpath")String jsonpath) {
        String result = JsonPath.read(jsonstring, jsonpath).toString();
        return result;
    }
    
    public JsonPathUtils() {
        super();
    }
/*    
    public static void main(String[] args) {
        JsonPathUtils myPath = new JsonPathUtils();
        System.out.println(myPath.ExecuteJsonPath("{ \"store\": {\n" + 
        "    \"book\": [ \n" + 
        "      { \"category\": \"reference\",\n" + 
        "        \"author\": \"Nigel Rees\",\n" + 
        "        \"title\": \"Sayings of the Century\",\n" + 
        "        \"price\": 8.95\n" + 
        "      },\n" + 
        "      { \"category\": \"fiction\",\n" + 
        "        \"author\": \"Evelyn Waugh\",\n" + 
        "        \"title\": \"Sword of Honour\",\n" + 
        "        \"price\": 12.99,\n" + 
        "        \"isbn\": \"0-553-21311-3\"\n" + 
        "      }\n" + 
        "    ],\n" + 
        "    \"bicycle\": {\n" + 
        "      \"color\": \"red\",\n" + 
        "      \"price\": 19.95\n" + 
        "    }\n" + 
        "  }\n" + 
        "}", "$.store.book[1].author"));
    }
*/
}
