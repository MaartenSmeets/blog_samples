package ms.testapp;

public interface IJsonPathUtils {
	public String ExecuteJsonPath(String jsonstring,String jsonpath);
}
