package ms.testapp.soa.util;

import com.fasterxml.jackson.core.JsonFactory;

import com.fasterxml.jackson.core.JsonParser;

import com.fasterxml.jackson.databind.JsonNode;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.BooleanNode;

import com.fasterxml.jackson.databind.node.DoubleNode;

import com.fasterxml.jackson.databind.node.NullNode;

import com.fasterxml.jackson.databind.node.ObjectNode;

import com.fasterxml.jackson.databind.node.TextNode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.Iterator;


import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;

import javax.xml.bind.Marshaller;


import ms.testapp.soa.util.model.Array;
import ms.testapp.soa.util.model.Member;
import ms.testapp.soa.util.model.Null;
import ms.testapp.soa.util.model.ObjectFactory;
import ms.testapp.soa.util.model.Object;


import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.lang.StringEscapeUtils;

@WebService
public class JsonXml {

    //converts String containing Json to JsonNode object
    private JsonNode StringToJson(String JsonStr) {
        JsonFactory factory = new JsonFactory();
        JsonParser jp = null;
        JsonNode actualObj = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            actualObj = mapper.readValue(JsonStr, JsonNode.class);
            jp = factory.createJsonParser(JsonStr);
        } catch (Exception e) {
            System.out.println(Common.stackTraceToString(e));
        }
        return actualObj;
    }

    //Converts Json to XML in a fixed format
    public Member JsonToFixedXml(String Json) {
        Member myMember = parseNode(StringToJson(Json));
        return myMember;
    }
    
    //Converts XML (in a fixed format) to a Json string
    public String FixedXmlToJson(Member mymember) {
        JsonNode mynode= parseXml(mymember);
        return mynode.toString();
    }
    
    //tests if the conversion from Json to XML is reversable (if all Json types and Xml types are supported by the conversion)
    public String testConversion(String myJson) {
        JsonNode actualObj = StringToJson(myJson);
                
        Member myMember = JsonToFixedXml(myJson);
        String result = FixedXmlToJson(myMember);
        JsonNode resultObj = StringToJson(result);
        
        if (actualObj.equals(resultObj)) {
            return "Conversion success!";
        } else {
            return "Conversion failed!: In="+myJson+" Out="+result;
        }
    }

    private JsonNode parseXml(Member mymember) {
        ObjectMapper m = new ObjectMapper();
        JsonNode retval = m.createObjectNode();
        //System.out.println(mymember.getValue().getDeclaredType().getCanonicalName());
        
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(Boolean.class.getCanonicalName())) {
            retval = parseXMLBoolean(mymember);
        }
        
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(Double.class.getCanonicalName())) {
            retval = parseXMLDouble(mymember);
        }
        
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(String.class.getCanonicalName())) {
            retval = parseXMLString(mymember);
        }
        
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(Null.class.getCanonicalName())) {
            retval = parseXMLNull(mymember);
        }
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(Array.class.getCanonicalName())) {
            retval = parseXMLArray(mymember);
        }
        if (mymember.getValue().getDeclaredType().getCanonicalName().equals(Object.class.getCanonicalName())) {
            retval = parseXMLObject(mymember);
        }

        return retval;
    }

    private JsonNode parseXMLBoolean(Member mymember) {
        Boolean myval = ((JAXBElement<Boolean>)mymember.getValue()).getValue();
        BooleanNode retval = BooleanNode.valueOf(myval);
        return retval;
    }
    
   private JsonNode parseXMLString(Member mymember) {
        String myval = ((JAXBElement<String>)mymember.getValue()).getValue();
        TextNode retval = TextNode.valueOf(myval);
        return retval;
    }

   private JsonNode parseXMLDouble(Member mymember) {
        Double myval = (((JAXBElement<Double>)mymember.getValue()).getValue());
        DoubleNode retval = DoubleNode.valueOf(myval);
        return retval;
    }
    private JsonNode parseXMLNull(Member mymember) {
        return NullNode.getInstance();
    }
    
   private JsonNode parseXMLObject(Member mymember) {
        ObjectMapper m = new ObjectMapper();
        ObjectNode retval = m.createObjectNode();
        
        JAXBElement<Object> myObj = (JAXBElement<Object>)mymember.getValue();
        Object myObject = myObj.getValue();
        List<Member> myList = myObject.getMember();
        
        for (Member myMem : myList) {
            JsonNode myNode = parseXml(myMem);
            retval.put(myMem.getName(),  myNode);
        }
        return retval;
    }

   private JsonNode parseXMLArray(Member mymember) {
        ObjectMapper m = new ObjectMapper();
        ArrayNode retval = m.createArrayNode();
        ObjectFactory o = new ObjectFactory();
        
        JAXBElement<Array> myObj = (JAXBElement<Array>)mymember.getValue();
        Array myArray = myObj.getValue();
        Member myMemC = o.createMember();
        
        for (JAXBElement myMem : myArray.getValue()) {
            myMemC.setValue( myMem);
            JsonNode myNode = parseXml(myMemC);
            retval.add(myNode);
        }
        return retval;
    }



    private Member parseNode(JsonNode mynode) {
        ObjectFactory myFact = new ObjectFactory();
        Member myMember = myFact.createMember();
        if (mynode != null) {
        if (mynode.isArray()) {
            //System.out.println("Node is array");
            myMember.setValue(parseArrayNode(mynode).getValue());
        }
        if (mynode.isObject()) {
            //System.out.println("Node is object");
            myMember.setValue(parseObjectNode(mynode).getValue());
        }
        if (mynode.isTextual()) {
            //System.out.println("Node is textual");
            myMember.setValue(parseTextNode(mynode).getValue());
        }
        if (mynode.isNumber()) {
            //System.out.println("Node is number");
            myMember.setValue(parseDoubleNode(mynode).getValue());
        }
        if (mynode.isBoolean()) {
            //System.out.println("Node is boolean");
            myMember.setValue(parseBooleanNode(mynode).getValue());
        }
        if (mynode.isNull()) {
            //System.out.println("Node is null");
            myMember.setValue(parseNullNode(mynode).getValue());
        }
        }

        return myMember;
    }

    private Member parseTextNode(JsonNode mytext) {
        ObjectFactory myFact = new ObjectFactory();
        Member myMember = myFact.createMember();
        JAXBElement<String> myEl = myFact.createString(mytext.textValue());
        myMember.setValue(myEl);
        //System.out.println("TextNode = " + mytext.textValue());
        return myMember;
    }

    private Member parseNullNode(JsonNode mytext) {
        ObjectFactory myFact = new ObjectFactory();
        Member myMember = myFact.createMember();
        JAXBElement<Null> myEl = myFact.createNull(new Null());
        myMember.setValue(myEl);
        //System.out.println("NullNode");
        return myMember;
    }

   private Member parseDoubleNode(JsonNode mynumber) {
        ObjectFactory myFact = new ObjectFactory();
        Member myMember = myFact.createMember();
        JAXBElement<Double> myEl = myFact.createNumber(mynumber.asDouble());
        myMember.setValue(myEl);
        //System.out.println("DoubleNode = " + mynumber.asDouble());
        return myMember;
    }

   private Member parseBooleanNode(JsonNode mynumber) {
        ObjectFactory myFact = new ObjectFactory();
        Member myMember = myFact.createMember();
        JAXBElement<Boolean> myEl = myFact.createBoolean(mynumber.asBoolean());
        myMember.setValue(myEl);
        //System.out.println("BooleanNode = " + mynumber.asBoolean());
        return myMember;
    }


    private Member parseArrayNode(JsonNode myarray) {
        ObjectFactory myFact = new ObjectFactory();
        Member retval = myFact.createMember();
        Array myXMLArray = myFact.createArray();
        Iterator<JsonNode> nodeIterator = myarray.elements();
        //System.out.println("Array size = " + ((ArrayNode)myarray).size());
        while (nodeIterator.hasNext()) {
            JsonNode element = nodeIterator.next();
            myXMLArray.getValue().add(parseNode(element).getValue());
        }

        JAXBElement<Array> myArr = myFact.createArray(myXMLArray);
        retval.setValue(myArr);
        return retval;
    }

    private Member parseObjectNode(JsonNode myObject) {
        ObjectFactory myFact = new ObjectFactory();
        Member retval = myFact.createMember();
        Object myXMLObject = myFact.createObject();
        Iterator<Map.Entry<String, JsonNode>> myIt = myObject.fields();
        while (myIt.hasNext()) {
            Map.Entry<String, JsonNode> element = myIt.next();
            //System.out.println("Object name = " + element.getKey());
            Member memEl = parseNode(element.getValue());
            memEl.setName(element.getKey());
            myXMLObject.getMember().add(memEl);
        }
        JAXBElement<Object> myObjXML = myFact.createObject(myXMLObject);
        retval.setValue(myObjXML);
        return retval;
    }

    public static void main(String[] args) {

        String Json = "{\n" +
            "  \"foo\":\n" +
            "   [true,null,1.23,\n" +
            "	{\n" +
            "	 \"bar\":\"spam\"\n" +
            "	}\n" +
            "   ]\n" +
            " }";
        /*
       * {"foo":[true,null,1.23,{"bar":"spam"}]}
       */
        
        JsonXml me = new JsonXml();
        System.out.println(me.testConversion(Json));

    }

}
