@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xmlsh.org/jxml",
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ms.testapp.soa.util.model;

