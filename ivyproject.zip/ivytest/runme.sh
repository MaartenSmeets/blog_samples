#!/bin/sh
/home/maarten/Oracle/Middleware1213/Oracle_Home/oracle_common/modules/org.apache.ant_1.9.2/bin/ant -lib /home/maarten/ivytest/apache-ivy-2.4.0-rc1
