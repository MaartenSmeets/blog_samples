package nl.amis.smeetsm.jms.sample;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.HashMap;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.codec.binary.Base64;

@WebService
public class JMSPublisherWS {

    public JMSPublisherWS() {
        super();
    }

    private Context getContext() throws NamingException {
        return new InitialContext();
    }

    private String getStackTrace(Throwable ex) {
        StringWriter errors = new StringWriter();
        ex.printStackTrace(new PrintWriter(errors));
        return errors.toString();
    }

    private TextMessage getTextMessage(Session session, String strmsg, HashMap<String, JMSPropertyValue> JMSProperties,
                                       HashMap<String, String> JMSHeaders) throws JMSException {
        TextMessage msg;
        msg = session.createTextMessage();
        msg.setText(strmsg);
        JMSPropertyValue property;

        if (JMSProperties != null) {
            for (String key : JMSProperties.keySet()) {
                property = JMSProperties.get(key);
                if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.STRING)) {
                    msg.setStringProperty(key, JMSProperties.get(key).getValue());
                } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.INT)) {
                    msg.setIntProperty(key, Integer.parseInt(JMSProperties.get(key).getValue()));
                } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.BOOLEAN)) {
                    msg.setBooleanProperty(key, Boolean.parseBoolean(JMSProperties.get(key).getValue()));
                } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.FLOAT)) {
                    msg.setFloatProperty(key, Float.parseFloat(JMSProperties.get(key).getValue()));
                } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.DOUBLE)) {
                    msg.setDoubleProperty(key, Double.parseDouble(JMSProperties.get(key).getValue()));
                }
            }
        }

        if (JMSHeaders != null) {
            for (String key : JMSHeaders.keySet()) {
                if (key.equalsIgnoreCase("JMSCorrelationID")) {
                    msg.setJMSCorrelationID(JMSHeaders.get(key));
                } else if (key.equalsIgnoreCase("JMSMessageID")) {
                    msg.setJMSMessageID(JMSHeaders.get(key));
                } else if (key.equalsIgnoreCase("JMSType")) {
                    msg.setJMSType(JMSHeaders.get(key));
                } else if (key.equalsIgnoreCase("JMSDeliveryMode")) {
                    msg.setJMSDeliveryMode(Integer.parseInt(JMSHeaders.get(key)));
                } else if (key.equalsIgnoreCase("JMSPriority")) {
                    msg.setJMSPriority(Integer.parseInt(JMSHeaders.get(key)));
                } else if (key.equalsIgnoreCase("JMSExpiration")) {
                    msg.setJMSExpiration(Long.parseLong(JMSHeaders.get(key)));
                } else if (key.equalsIgnoreCase("JMSTimestamp")) {
                    msg.setJMSTimestamp(Long.parseLong(JMSHeaders.get(key)));
                }
            }
        }

        return msg;
    }

    private MessageResponse produceMessage(ConnectionFactory confact, Destination dest,
                                           HashMap<String, JMSPropertyValue> JMSProperties,
                                           HashMap<String, String> JMSHeaders, String textMsg) {

        Connection tCon;
        try {
            tCon = confact.createConnection();
        } catch (JMSException e) {
            return new MessageResponse("ERROR", "Unable to create Connection: " + getStackTrace(e));
        }

        Session session;

        try {
            session = tCon.createSession(false, /* not a transacted session */
                                         Session.AUTO_ACKNOWLEDGE);
        } catch (JMSException e) {
            return new MessageResponse("ERROR", "Unable to create Session: " + getStackTrace(e));
        }

        MessageProducer producer;
        try {
            producer = session.createProducer(dest);
        } catch (JMSException e) {
            return new MessageResponse("ERROR", "Unable to create MessageProducer: " + getStackTrace(e));
        }

        TextMessage msg;
        try {
            msg = getTextMessage(session, textMsg, JMSProperties, JMSHeaders);
        } catch (JMSException e) {
            return new MessageResponse("ERROR", "Unable to create TextMessage: " + getStackTrace(e));
        }

        try {
            producer.send(msg);
        } catch (JMSException e) {
            return new MessageResponse("ERROR", "Unable to produce TextMessage: " + getStackTrace(e));
        }

        return new MessageResponse("OK", "Message send");
    }

    private String decodeBase64(byte[] encoded) {
        byte[] valueDecoded = Base64.decodeBase64(encoded);
        return new String(valueDecoded);
    }

    private ConnectionFactory getConnectionFactory(Context ctx) throws NamingException {
        return (ConnectionFactory) ctx.lookup("weblogic.jms.ConnectionFactory");
    }

    /**
     * Entry method. Exposed as webservice operation
     * @param JMSJNDI JNDI name of the Queue or Topic to publish the message on
     * @param JMSHeaders HashMap describing the JMSHeaders which need to be added
     * @param base64Msg The message encoded in base64 which should be put in the queue. it is decoded to a TextMessage using the default charset
     * @return code/message pair. ERROR is problem, OK is not
     */
    @WebMethod
    public MessageResponse produceMessage(@WebParam(name = "JMSJNDI") String JMSJNDI,
                                          @WebParam(name = "JMSProperties")
                                          HashMap<String, JMSPropertyValue> JMSProperties,
                                          @WebParam(name = "JMSHeaders") HashMap<String, String> JMSHeaders,
                                          @WebParam(name = "base64Msg") String base64Msg) {
        if (JMSJNDI == null) {
            return new MessageResponse("ERROR", "JMSJNDI not specified");    
        }
        
        Context ctx;
        try {
            ctx = getContext();
        } catch (NamingException e) {
            return new MessageResponse("ERROR", "Unable to determine InitialContext: " + getStackTrace(e));
        }

        Destination JMSDestination;

        try {
            JMSDestination = (Destination) ctx.lookup(JMSJNDI);
        } catch (NamingException e) {
            return new MessageResponse("ERROR", "Unable to lookup JMS JNDI " + JMSJNDI + ": " + getStackTrace(e));
        }

        ConnectionFactory confact;
        try {
            confact = getConnectionFactory(ctx);
        } catch (NamingException e) {
            return new MessageResponse("ERROR", "Unable to obtain TopicConnectionFactory: " + getStackTrace(e));
        }

        return produceMessage(confact, (Topic) JMSDestination, JMSProperties, JMSHeaders,
                              decodeBase64(base64Msg.getBytes()));
    }
}

