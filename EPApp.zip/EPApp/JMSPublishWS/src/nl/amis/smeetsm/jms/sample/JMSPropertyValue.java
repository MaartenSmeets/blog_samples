package nl.amis.smeetsm.jms.sample;

public class JMSPropertyValue {
    public JMSPropertyValue.JMSPROPERTYTYPE getJmspropertytype() {
        return jmspropertytype;
    }

    public void setJmspropertytype(JMSPropertyValue.JMSPROPERTYTYPE jmspropertytype) {
        this.jmspropertytype = jmspropertytype;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public enum JMSPROPERTYTYPE { STRING,INT,DOUBLE,FLOAT,BOOLEAN,BYTE}
    
    private JMSPROPERTYTYPE jmspropertytype;
    private String value;
    
    public JMSPropertyValue() {}
    
    public JMSPropertyValue( JMSPROPERTYTYPE jmspropertytype,String name,String value) {
        this.setJmspropertytype(jmspropertytype);
        this.setValue(value);
    }
    
    
}
